#ifndef	_UART_H
#define _UART_H

#include "main.h"

void pc_command();
void ModbusTxData();

#endif
